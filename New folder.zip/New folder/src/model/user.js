import sequelize from "../config/database";

const { DataTypes } = require("sequelize");
const user = sequelize.define(
    "user",
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        name: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email:
        {
            type: DataTypes.STRING,
            allowNull: false,
            unique: true,
        },
        password:
        {
            type: DataTypes.STRING,
            allowNull: false,
        },
        type: {
            type: DataTypes.ENUM('customer', 'vendor'),
            defaultValue: 'customer',
            allowNull: false,
        },
    },
    {
        timestamps: true,
    }
);
module.export = user;