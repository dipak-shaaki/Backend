require('dotenv').config();
const { Sequelize } = require('sequelize');

const db_uri = process.env.DB_URI;

if (!db_uri) {
  throw new Error('DB_URI is missing from .env file');
}

const sequelize = new Sequelize(db_uri, {
  dialect: 'postgres',
});

module.exports = sequelize;
