
const express = require('express');
const sequelize = require('./config/db');

const app = express();


sequelize.authenticate()
  .then(() => {
    console.log(' DB connected');
  
  })
  .catch((err) => {
    console.error('DB error:', err.message);
   
  });

app.get('/', (req, res) => {
  res.send('API running');
});
